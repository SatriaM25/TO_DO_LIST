package com.example.todolist2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import androidx.recyclerview.widget.RecyclerView
import android.widget.Spinner




class ActivityAdapter : RecyclerView.Adapter<ActivityAdapter.ActivityViewHolder>() {
    private var activityList: ArrayList<ActivityModel> = ArrayList()
    private var onClickItem: ((ActivityModel) -> Unit)? = null
    private var onClickDeleteItem: ((ActivityModel) -> Unit)? = null

    fun addItems(items: ArrayList<ActivityModel>) {
        this.activityList = items
        notifyDataSetChanged()
    }

    fun setOnClickItem(callback: (ActivityModel) -> Unit) {
        this.onClickItem = callback
    }

    fun setOnClickDeleteItem(callback: (ActivityModel) -> Unit) {
        this.onClickDeleteItem = callback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ActivityViewHolder (
        LayoutInflater.from(parent.context).inflate(R.layout.card_items_std, parent, false)
    )

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        val actv = activityList[position]
        holder.bindView(actv)
        holder.itemView.setOnClickListener { onClickItem?.invoke(actv) }
        holder.btnDelete.setOnClickListener { onClickDeleteItem?.invoke(actv) }
    }

    override fun getItemCount(): Int {
        return activityList.size
    }

    class ActivityViewHolder(var view: View) : RecyclerView.ViewHolder(view) {
        private var id = view.findViewById<TextView>(R.id.tvId)
        private var activity = view.findViewById<TextView>(R.id.tvActivity)
        private var desc = view.findViewById<TextView>(R.id.tvDesc)
        private var date = view.findViewById<TextView>(R.id.tvDate)
        private var time = view.findViewById<TextView>(R.id.tvTime)

        var btnDelete = view.findViewById<Button>(R.id.btnDelete)


        fun bindView(actv: ActivityModel) {
            id.text = actv.id.toString()
            activity.text = actv.activity
            desc.text = actv.desc
            date.text = actv.date
            time.text = actv.time
        }
    }

//    private fun getIndex(spinner: Spinner, myString: String): Int {
//        for (i in 0 until spinner.count) {
//            if (spinner.getItemAtPosition(i).toString().equals(myString, ignoreCase = true)) {
//                return i
//            }
//        }
//        return 0
//    }
}