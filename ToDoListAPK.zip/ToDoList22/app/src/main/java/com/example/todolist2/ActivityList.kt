package com.example.todolist2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class ActivityList : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private var adapter: ActivityAdapter? = null
    lateinit var sqliteHelper: SQLiteHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        recyclerView = findViewById(R.id.recyclerView)
        initRecyclerView()

        sqliteHelper = SQLiteHelper(this)
        getActivities()

        adapter?.setOnClickItem {
            //update record
            val dateResult = it.date.split("/").toTypedArray()
            val timeResult = it.time.split(":"," ").toTypedArray()


            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("activityValue", it.activity)
            intent.putExtra("descValue", it.desc)
            intent.putExtra("dayValue", dateResult[2])
            intent.putExtra("monthValue", dateResult[1])
            intent.putExtra("yearValue", dateResult[0])
            intent.putExtra("hourValue", timeResult[0])
            intent.putExtra("minValue", timeResult[1])
            intent.putExtra("ampmValue", timeResult[2])
            intent.putExtra("actvModel", it)
            startActivity(intent)
        }

        adapter?.setOnClickDeleteItem {
            deleteActivity(it.id)
        }
    }


    private fun getActivities() {
        val actvList = sqliteHelper.getAllActivity()
        Log.e("pppp", "${actvList.size}")

        //display data in recyclerview
        adapter?.addItems(actvList)
    }

    private fun deleteActivity(id: Int) {
        if (id == null) return

        val builder = AlertDialog.Builder(this)
        builder.setMessage("sure want to delete?")
        builder.setCancelable(true)
        builder.setPositiveButton("Yes") { dialog, _ ->
            sqliteHelper.deleteStudentById(id)
            dialog.dismiss()
            val intent = Intent(this, this::class.java)
            startActivity(intent)
            overridePendingTransition(0, 0)
            finish()
        }
        builder.setNegativeButton("no") { dialog, _ ->
            dialog.dismiss()
        }

        val alert = builder.create()
        alert.show()


    }

    private fun initRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ActivityAdapter()
        recyclerView.adapter = adapter
    }
}