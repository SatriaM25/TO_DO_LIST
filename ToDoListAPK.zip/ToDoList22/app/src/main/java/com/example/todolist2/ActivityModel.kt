package com.example.todolist2

import java.io.Serializable
import java.util.*

data class ActivityModel (
    var id: Int = getAutoId(),
    var activity: String = "",
    var date: String = "",
    var time: String = "",
    var desc: String = ""
) : Serializable {
    companion object{
        fun getAutoId(): Int {
            val random = Random()
            return random.nextInt(100)
        }
    }
}