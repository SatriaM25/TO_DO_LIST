package com.example.todolist2

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var edActivity: EditText
    lateinit var edDesc: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnView: Button
    private lateinit var btnUpdate: Button

    private lateinit var datePicker: DatePicker
    private lateinit var timePicker: TimePicker
    private lateinit var calendar: Calendar
    private var bundle : Bundle? = null
    private lateinit var time: String
    private lateinit var date: String


    lateinit var sqliteHelper: SQLiteHelper
    private var actvModel: ActivityModel? = null

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initView()

        sqliteHelper = SQLiteHelper(this)

        calendar = Calendar.getInstance()
        bundle = intent.extras

        if(bundle != null){
            edActivity.setText(bundle!!.getString("activityValue"))
            edDesc.setText(bundle!!.getString("descValue"))
            actvModel = intent.getSerializableExtra("actvModel") as? ActivityModel
            calendar.set(bundle!!.getString("dayValue")!!.toInt(), bundle!!.getString("monthValue")!!.toInt()-1, bundle!!.getString("yearValue")!!.toInt())
            setDate(
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )

            val x = if (bundle!!.getString("ampmValue") == "PM") 12 else 0
            timePicker.hour = bundle!!.getString("hourValue")!!.toInt() + x
            timePicker.minute = bundle!!.getString("minValue")!!.toInt()
            edActivity.setText(bundle!!.getString("activityValue"))
        } else{
            timePicker.hour = 0
            timePicker.minute = 0
            setDate(
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
        }


//        val datePicker = findViewById<DatePicker>(R.id.date_Picker)
//        val today = Calendar.getInstance()
//        datePicker.init(today.get(Calendar.YEAR), today.get(Calendar.MONTH),
//            today.get(Calendar.DAY_OF_MONTH)
//
//        ) { view, year, month, day ->
//            val month = month + 1
//            date = "$day/$month/$year"
//            val msg = "You Selected: $day/$month/$year"
//            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
//        }

//        val timePicker = findViewById<TimePicker>(R.id.time_Picker)
//        val hour = timePicker.hour
//        val min = timePicker.minute
//        time = "$hour : $min"
//        timePicker.setHour(0)
//        timePicker.setMinute(0)
        timePicker.setOnTimeChangedListener { _, hour, minute -> var hours = hour
            var am_pm = ""
            // AM_PM decider logic
            when {hour == 0 -> { hours += 12
                am_pm = "AM"
            }
                hour == 12 -> am_pm = "PM"
                hour > 12 -> { hours -= 12
                    am_pm = "PM"
                }
                else -> am_pm = "AM"
            }

            val hour = if (hours < 10) "0" + hours else hours
            val min = if (minute < 10) "0" + minute else minute
            // display format of time
            time = "$hour:$min $am_pm"
            val msg = "Time is: $hour : $min $am_pm"
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()

        }




        btnAdd.setOnClickListener { addActivity() }
        btnView.setOnClickListener {
            val intent = Intent(this, ActivityList::class.java)
            startActivity(intent)
        }
        btnUpdate.setOnClickListener { updateActivity() }

    }

    fun setDate(setYear:Int, setMonth:Int, setDay:Int){
        calendar.set(setYear,setMonth,setDay)
        datePicker.init(setYear, setMonth, setDay

        ) { view, year, month, day ->
            val month = month + 1
            date = "$day/$month/$year"
            val msg = "You Selected: $day/$month/$year"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun addActivity() {
        val activity = edActivity.text.toString()
        val desc = edDesc.text.toString()

        if (activity.isEmpty() || desc.isEmpty() || datePicker == null || timePicker == null) {
            Toast.makeText(this, "Please enter required field", Toast.LENGTH_SHORT).show()
        } else {
            val actvModel = ActivityModel(activity = activity, desc = desc, date = date, time = time)
            val status = sqliteHelper.insertActivity(actvModel)
            //check insert success or not
            if (status > -1) {
                Toast.makeText(this, "Added.....", Toast.LENGTH_SHORT).show()
                clearEditText()
            } else{
                Toast.makeText(this, "not added.....", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateActivity() {
        val activity = edActivity.text.toString()
        val desc = edDesc.text.toString()

        //check record not change

        if (activity == actvModel?.activity && desc == actvModel?.desc && date == actvModel?.date && time == actvModel?.time) {
            Toast.makeText(this, "record not changed..", Toast.LENGTH_SHORT).show()
            return
        }

        if (actvModel == null) return

        val actvModel = ActivityModel(id = actvModel!!.id, activity = activity, desc = desc, date = date, time = time)
        val status = sqliteHelper.updateActivity(actvModel)
        if (status > -1) {
            clearEditText()
        } else {
            Toast.makeText(this, "Update fail", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearEditText(){
        edActivity.setText("")
        edDesc.setText("")
        edActivity.requestFocus()
    }



    private fun initView(){
        edActivity = findViewById(R.id.edActivity)
        edDesc = findViewById(R.id.edDesc)
        btnAdd = findViewById(R.id.btnAdd)
        btnView = findViewById(R.id.btnView)
        btnUpdate = findViewById(R.id.btnUpdate)
        datePicker = findViewById(R.id.date_Picker)
        timePicker = findViewById(R.id.time_Picker)
    }
}