package com.example.todolist2

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.*

class SQLiteHelper(context:Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object{
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "student.db"
        private const val TBL_ACTIVITY = "tbl_activity"
        private const val ID = "id"
        private const val ACTIVITY = "activity"
        private const val DESC = "desc"
        private const val DATE = "date"
        private const val TIME = "time"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTblActivity = ("CREATE TABLE " + TBL_ACTIVITY + "("
                + ID + " INTEGER PRIMARY KEY," + ACTIVITY + " TEXT,"
                + DATE + " TEXT,"
                + TIME + " TEXT,"
                + DESC + " TEXT" + ");")
        db?.execSQL(createTblActivity)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TBL_ACTIVITY")
        onCreate(db)
    }

    fun insertActivity(actv: ActivityModel): Long{
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(ID, actv.id)
        contentValues.put(ACTIVITY, actv.activity)
        contentValues.put(DESC, actv.desc)
        contentValues.put(TIME, actv.time)
        contentValues.put(DATE, actv.date)

        val success = db.insert(TBL_ACTIVITY, null, contentValues)
        db.close()
        return success
    }

    fun getAllActivity(): ArrayList<ActivityModel> {
        val actvList: ArrayList<ActivityModel> = ArrayList()
        val selectQuery = "SELECT * FROM $TBL_ACTIVITY"
        val db = this.readableDatabase

        val cursor: Cursor?

        try{
            cursor = db.rawQuery(selectQuery, null)
        } catch (e: Exception){
            e.printStackTrace()
            db.execSQL(selectQuery)
            return ArrayList()
        }

        var id: Int
        var activity: String
        var desc: String
        var date: String
        var time: String

        if (cursor.moveToFirst()){
            do{
                id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                activity = cursor.getString(cursor.getColumnIndexOrThrow("activity"))
                desc = cursor.getString(cursor.getColumnIndexOrThrow("desc"))
                date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                time = cursor.getString(cursor.getColumnIndexOrThrow("time"))

                val actv = ActivityModel(id = id, activity = activity, desc = desc, date = date, time = time)
                actvList.add(actv)
            } while (cursor.moveToNext())
        }

        return actvList
    }

    fun updateActivity(actv: ActivityModel): Int{
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(ID, actv.id)
        contentValues.put(ACTIVITY, actv.activity)
        contentValues.put(DESC, actv.desc)
        contentValues.put(DATE, actv.date)
        contentValues.put(TIME, actv.time)

        val success = db.update(TBL_ACTIVITY, contentValues, "id=" + actv.id, null)
        db.close()
        return success
    }

    fun deleteStudentById(id: Int): Int{
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(ID, id)

        val success = db.delete(TBL_ACTIVITY, "id=$id", null)
        db.close()
        return success
    }

}